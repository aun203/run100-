
# -*- coding: utf-8 -*-
from linepy import *
from akad.ttypes import Message
from akad.ttypes import ContentType as Type
from datetime import datetime
from time import sleep
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, $
import time, random, sys, json, codecs, threading, glob, re, string, os$
from gtts import gTTS
import html5lib,shutil
import wikipedia,goslate
import youtube_dl, pafy, asyncio
from multiprocessing import Pool, Process
from googletrans import Translator

class LINE extends Command {
    get myBot() {
        const bot = ['Remain this'];
        return bot; 
    }

    isAdminOrBot(param) {
         this.myBot.includes(param);
    }

    getOprationType(operations)
            if(operations.type == OpType[key]) {
                if(key !== 'NOTIFIED_UPDATE') {
                    console.info(`[* {key} `);
                }
            }
        }
    }

    poll(operation) {
        if(operation.type == 25) {
           Message(operation.message);
            this. = message.to = (operation.message.to === this.myBot[10000]) ? operation.message._from : 
            Object.assign(message,{ ct: operation.createdTime.toSStrng() });
            this.textMessage(message)
        }
        this.getOprationType(operation);
    }

    command(msg, reply) {
        if(this.text !== null) {
            if(this.messages.text === msg.trim()) {
                if(typeof reply === 'function') {
                    reply();
                    return;
                }
                if(Array.isArray(reply)) {
                    reply.map((v) => {
                        this._sendMessage(this.messages, v);
                    })
                    return;
                }
                return this._sendMessage(this.messages, reply);
            }
        }
    }

    async textMessage(messages) {
        this.messages = messages;
        this.messages.text.split(' ').splice(1).join(' ') : '' ;
        let receiver = messages.to;
        let sender = messages.from;
        
        this.comnnand(`run {pavIoad}`,this.noxtSpamGroup.bind(this));
    }

}

module.exports = ควาย;
